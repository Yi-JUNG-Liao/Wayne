let sym1 = Symbol("Sym")
console.log(sym1);
console.log(sym1.toString());