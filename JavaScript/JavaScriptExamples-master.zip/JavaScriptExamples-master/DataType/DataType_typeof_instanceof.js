var array1 = [1, 3, 5, 7];

//顯示型別
console.log(typeof array1);

//判斷是否為Array實例
console.log(array1 instanceof Array);