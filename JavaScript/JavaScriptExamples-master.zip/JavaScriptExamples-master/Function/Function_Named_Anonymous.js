//匿名函式Anonymous Function
function foo(){

}

//ECMAScript 2015 arrow function
//()=>{}


//Named Function具名函式
function foo(){

}

const bar = ()=>{ 

}