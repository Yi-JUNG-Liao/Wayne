//Ex1 -
for (let i = 0; i < 255; i++) {
    console.log(i + ", " + String.fromCharCode(i));
}


//Ex2 -
let ascii = '';
for (let i = 33; i < 255; i++) {
    ascii += String.fromCharCode(i);
}

console.log(ascii);



