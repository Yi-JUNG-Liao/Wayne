//Ex - string + number
var x = '2';
var y = 1;
console.log(x + y);

console.log(y - x);

//number + boolean
var foo = 1;
var bar = true;

console.log(foo == bar);
console.log(foo + bar);

//精度
console.log(0.1 + 0.2);